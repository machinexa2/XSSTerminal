import readline
from termcolor import colored

from lib.PathFunctions import PathFunction
from lib.Globals import ColorObj

FPathApp = PathFunction()

def banner():
    from pyfiglet import print_figlet as puff
    puff('XSS Terminal', font='larry3d', colors='BLUE')
    print(colored('XSS Terminal for interactive XSS testing', color='red', attrs=['bold']))

def starter(argv):
    if argv.banner:
        banner()
        exit(0)
    if not argv.resume:
        if not argv.base_url or not argv.payload:
            print(f"{ColorObj.bad} Use --help")
            exit()
        else:
            return argv.base_url, argv.payload
    if argv.resume:
        base, xss = xsst_parser(argv.resume)
        return base, xss

def xss_input(prompt, text):
        def hook():
            readline.insert_text(text)
            readline.redisplay()
        readline.set_pre_input_hook(hook)
        result = input(prompt)
        readline.set_pre_input_hook()
        return result

def exit_handler(base, xss, filename=None):
    if not filename:
        unurled = FPathApp.unurler(base).split('/')[0] + '.xsst'
        print(f"\n{ColorObj.good} Saving session in {unurled} for further use.")
        with open(unurled, 'w') as f:
            f.write(base + '|' + xss)
    else:
        unurled = filename + '.xsst'
        print(f"\n{ColorObj.good} Saving session in {unurled} for further use.")
        with open(unurled, 'w') as f:
            f.write(base + '|' + xss)
    exit()

def xsst_parser(resumefile) -> tuple:
    try:
        data = [line.rstrip('\n') for line in open(resumefile) if line]
        if not '|' in data or len(data) > 1:
            print(f"{ColorObj.bad} Invalid resume file")
    except Exception as E:
        print(f"{ColorObj.bad} Error {E} of class {E.__class__} occured.")
    base, xss = data.split('|')
    return base, xss

def post_parser(post_parameter) -> dict:
    postdict = dict()
    post = post_parameter.rstrip('&').lstrip('&=').split('&')
    for post_data in post:
        first, last = post_data.split('=')
        postdict[first] = last
    return postdict
