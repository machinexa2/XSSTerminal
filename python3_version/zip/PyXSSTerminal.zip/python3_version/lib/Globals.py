from lib.ColoredObject import Color as Cobj

User_Agent = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36',
    'X-Bug-Bounty': 'machinexa'
}

ColorObj = Cobj()
