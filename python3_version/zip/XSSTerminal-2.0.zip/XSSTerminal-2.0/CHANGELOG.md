# Version 2.0
* Added POST method
* Added blind string check
* Fix some bugs
* Cleaner code by moving some functions
* Improved README.md, added wiki, other small details
* Added match_string.php tests
