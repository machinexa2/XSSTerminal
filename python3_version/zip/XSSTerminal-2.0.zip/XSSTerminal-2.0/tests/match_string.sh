PyXSSTerminal -u http://127.0.0.1/match_string?pay= -p 'ls<script%20></script>'
